# octolog (development version)

* octolog is now compatible with rlang >= 0.4.10
* openssl is now optional as it is only used in `octo_stop_commands()`. 
  * An unsafe fallback is used to generate the token outside of Github Actions.
  
# octolog 0.1.1

* add CITATION

# octolog 0.1.0

* This is the initial release!
