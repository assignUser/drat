
options(keep.source = TRUE)
library(testthat)
library(octolog)

enable_github_colors()
test_check("octolog")
