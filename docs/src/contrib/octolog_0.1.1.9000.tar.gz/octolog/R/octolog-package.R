#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom glue glue
#' @importFrom magrittr %>%
#' @importFrom rlang %||%
## usethis namespace: end
NULL
